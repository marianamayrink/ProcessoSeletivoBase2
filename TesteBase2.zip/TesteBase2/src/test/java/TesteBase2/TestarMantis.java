package TesteBase2;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import static org.junit.Assert.assertEquals;

public class TestarMantis {

@Test
public void preencherCampos() {

    ChromeDriver driver = new ChromeDriver();

    driver.navigate().to("https://mantis-prova.base2.com.br/");
    //Efetuar Login
    WebElement usernameField = driver.findElement(By.name("username"));
    WebElement passwordField = driver.findElement(By.name("password"));
    WebElement loginButton = driver.findElement(By.xpath("//input[@value='Login']"));

    usernameField.sendKeys("mariana.mayrink");
    passwordField.sendKeys("871022");
    //   passwordField.sendKeys("123456"); Validando senha incorreta
    loginButton.click();

    driver.navigate().to ( " https://mantis-prova.base2.com.br/login_select_proj_page.php?ref=bug_report_page.php");

    //Verificar se entrou com usuario logado
    WebElement usuarioCorreto = driver.findElement(By.xpath("//td[@class='login-info-left']/span[@class='italic']"));
    Assert.assertEquals("mariana.mayrink",usuarioCorreto.getText());

    //Escolha o Projeto
    WebElement ProjetoField = driver.findElement(By.xpath("//td[@width='60%']/select[@name='project_id']"));
    Select comboProjeto = new Select(ProjetoField);
    comboProjeto.selectByVisibleText("Desafio jMeter Project 2");

    //Selecione o Projeto
    WebElement SelecioneProjetoButton = driver.findElement(By.xpath("//input[@value='Select Project']"));
    SelecioneProjetoButton.click();

    //Campo Categoria
    WebElement CategoriaField = driver.findElement(By.name("category_id"));
    Select comboCategoria = new Select(CategoriaField);
    comboCategoria.selectByVisibleText("[All Projects] 7EI2PODHPN");

    //Campo Frequencia
    WebElement FrequenciaField = driver.findElement(By.name("reproducibility"));
    Select comboFrequencia = new Select(FrequenciaField);
    comboFrequencia.selectByVisibleText("always");

    //Campo Gravidade
    WebElement GravidadeField = driver.findElement(By.name("severity"));
    Select comboGravidade = new Select(GravidadeField);
    comboGravidade.selectByVisibleText("trivial");

    //Campo Resumo
    WebElement ResumoField = driver.findElement(By.name("summary"));
    ResumoField.sendKeys("Teste Mariana Base 2");

    //Campo Descrição
    WebElement DescricaoField = driver.findElement(By.name("description"));
    DescricaoField.sendKeys("Teste descricao");

    //Campo Passos
    WebElement PassosField = driver.findElement(By.name("steps_to_reproduce"));
    PassosField.sendKeys("Teste passo");

    //Botão Enviar Relatório
    WebElement EnviarRelButton = driver.findElement(By.xpath("//input[@value='Submit Report']"));
    EnviarRelButton.click();

}
}
